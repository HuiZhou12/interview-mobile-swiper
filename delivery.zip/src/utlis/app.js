import { createApp } from 'vue';
import App from '../App.vue';

//创建应用实例对象--app
const app = createApp(App);

//暴露app
export default app;